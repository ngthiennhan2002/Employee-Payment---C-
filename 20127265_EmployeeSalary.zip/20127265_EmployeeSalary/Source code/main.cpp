#include "Header.h"

int main() {
	ReadFile reader(filename);
	vector<string> data = reader.read();

	Factory* factory = Factory::instance();
	ConvertToEmployee converter;
	for (int i = 0; i < data.size(); i += 2) {
		EmployeeType type = ConvertToEmployee::checkType(data[i]);
		Employee* temp = Employee::create(type);
		if (type == VT_DailyEmployee) {
			converter.convertToDailyEmployee(temp, data[i], data[i + 1]);
			factory->AddElement(temp);
		}
		else if (type == VT_HourlyEmployee) {
			converter.convertToHourlyEmployee(temp, data[i], data[i + 1]);
			factory->AddElement(temp);
		}
		else if (type == VT_ProductEmployee) {
			converter.convertToProductEmployee(temp, data[i], data[i + 1]);
			factory->AddElement(temp);
		}
		else if (type == VT_Manager) {
			converter.convertToManager(temp, data[i], data[i + 1]);
			factory->AddElement(temp);
		}
	}
	
	for (int i = 0; i < factory->GetEmployees().size(); i++) {
		Employee* employee = factory->GetEmployeeAt(i);
		cout << employee->toString() << endl;
	}

	system("pause");
	return 0;
}

// Output: Motobike is starting