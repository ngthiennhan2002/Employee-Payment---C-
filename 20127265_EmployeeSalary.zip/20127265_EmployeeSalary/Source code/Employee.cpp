#include "Employee.h"

Employee* Employee::create(EmployeeType type) {
	if (type == VT_DailyEmployee)
		return new DailyEmployee();
	else if (type == VT_HourlyEmployee)
		return new HourlyEmployee();
	if (type == VT_ProductEmployee)
		return new ProductEmployee();
	if (type == VT_Manager)
		return new Manager();
	else return NULL;
}