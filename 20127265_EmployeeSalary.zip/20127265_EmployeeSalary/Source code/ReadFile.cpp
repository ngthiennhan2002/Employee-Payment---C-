#include "ReadFile.h"

vector<string> ReadFile::read() {
	fstream file;
	file.open(_filename, ios::in);
	int count = 0;
	vector<string> data;
	while (!file.eof()) {
		string temp;
		count++;
		getline(file, temp);
		data.push_back(temp);
	}
	return data;
}