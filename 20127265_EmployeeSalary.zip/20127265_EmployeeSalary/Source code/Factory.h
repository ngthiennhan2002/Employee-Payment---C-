#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>
#include <math.h>
#include <vector>
#include <memory>
#include "ConvertToEmployee.h"
#include "Employee.h"
using namespace std;

class Factory
{
private:
	vector<Employee*> _employees;
	inline static Factory* _instance = NULL;
private:
	Factory(){}
public:
	static Factory* instance() {
		if (_instance == NULL)
			_instance = new Factory();
		return _instance;
	}
	void AddElement(Employee* employee) {
		_employees.push_back(employee);
	}

	Employee* GetEmployeeAt(int i) {
		return _employees[i];
	}

	vector<Employee*> GetEmployees() {
		return _employees;
	}
};

