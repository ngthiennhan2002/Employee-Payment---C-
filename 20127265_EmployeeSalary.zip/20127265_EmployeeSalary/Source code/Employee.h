#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>
#include <math.h>
#include <vector>
#include <memory>
using namespace std;

enum EmployeeType {
	VT_DailyEmployee,
	VT_HourlyEmployee,
	VT_ProductEmployee,
	VT_Manager,
	VT_NULL
};

class Employee
{
public:
	static Employee* create(EmployeeType);
	Employee() {}
public:
	virtual void SetDataEmployee(string a, int b, int c){}
	virtual void SetDataManager(string a, int b, int c, int d) {}
public:
	virtual string GetType() { return ""; }
	virtual string GetName() { return ""; }
	virtual int GetDailyPayment() { return 0; }
	virtual int GetTotalDays() { return 0; }
	virtual int GetHourlyPayment() { return 0; }
	virtual int GetTotalHours() { return 0; }
	virtual int GetPaymentPerProduct() { return 0; }
	virtual int GetTotalProducts() { return 0; }
	virtual int GetFixedPayment() { return 0; }
	virtual int GetTotalEmployees() { return 0; }
	virtual int GetPaymentPerEmployee() { return 0; }
public:
	virtual void CalculateTotal() {}
	virtual int GetTotal() { return 0; }
	virtual string toString() { return ""; }
};


class DailyEmployee : public Employee {
private:
	string _type = "DailyEmployee";
	string _name;
	int _dailyPayment;
	int _totalDays;
	int _total;
public:
	DailyEmployee(){}
	string GetType() { return _type; }
	string GetName() { return _name; }
	int GetDailyPayment() { return _dailyPayment; }
	int GetTotalDays() { return _totalDays; }
public:
	void SetDataEmployee(string name, int dailyPayment, int totalDays) {
		_name = name;
		_dailyPayment = dailyPayment;
		_totalDays = totalDays;
	}
public:
	void CalculateTotal() {
		_total = _dailyPayment * _totalDays;
	}
	int GetTotal() { return _total; }
	string toString() {
		stringstream out;
		out << _type << ": " << endl;
		out << "- Name: " << _name << endl;
		out << "- DailyPayment: " << _dailyPayment << endl;
		out << "- TotalDays: " << _totalDays << endl;
		out << "=> Final payment: " << _total << endl;
		return out.str();
	}
};


class HourlyEmployee : public Employee {
private:
	string _type = "HourlyEmployee";
	string _name;
	int _hourlyPayment;
	int _totalHours;
	int _total;
public:
	HourlyEmployee(){}
	string GetType() { return _type; }
	string GetName() { return _name; }
	int GetHourlyPayment() { return _hourlyPayment; }
	int GetTotalHours() { return _totalHours; }
public:
	void SetDataEmployee(string name, int a, int b) {
		_name = name;
		_hourlyPayment = a;
		_totalHours = b;
	}
public:
	void CalculateTotal() {
		_total = _hourlyPayment * _totalHours;
	}
	int GetTotal() { return _total; }
	string toString() {
		stringstream out;
		out << _type << ": " << endl;
		out << "- Name: " << _name << endl;
		out << "- HourlyPayment: " << _hourlyPayment << endl;
		out << "- TotalHours: " << _totalHours << endl;
		out << "=> Final payment: " << _total << endl;
		return out.str();
	}
};


class ProductEmployee : public Employee {
private:
	string _type = "ProductEmployee";
	string _name;
	int _paymentPerProduct;
	int _totalProducts;
	int _total;
public:
	ProductEmployee(){}
	string GetType() { return _type; }
	string GetName() { return _name; }
	int GetPaymentPerProduct() { return _paymentPerProduct; }
	int GetTotalProducts() { return _totalProducts; }
public:
	void SetDataEmployee(string name, int a, int b) {
		_name = name;
		_paymentPerProduct = a;
		_totalProducts = b;
	}
public:
	void CalculateTotal() {
		_total = _paymentPerProduct * _totalProducts;
	}
	int GetTotal() { return _total; }
	string toString() {
		stringstream out;
		out << _type << ": " << endl;
		out << "- Name: " << _name << endl;
		out << "- PaymentPerProduct: " << _paymentPerProduct << endl;
		out << "- TotalProducts: " << _totalProducts << endl;
		out << "=> Final payment: " << _total << endl;
		return out.str();
	}
};

class Manager : public Employee {
private:
	string _type = "Manager";
	string _name;
	int _fixedPayment;
	int _totalEmployees;
	int _paymentPerEmployee;
	int _total;
public:
	Manager(){}
	string GetType() { return _type; }
	string GetName() { return _name; }
	int GetFixedPayment() { return _fixedPayment; }
	int GetTotalEmployees() { return _totalEmployees; }
	int GetPaymentPerEmployee() { return _paymentPerEmployee; }
public:
	void SetDataManager(string name, int a, int b, int c) {
		_name = name;
		_fixedPayment = a;
		_totalEmployees = b;
		_paymentPerEmployee = c;
	}
public:
	void CalculateTotal() {
		_total = _fixedPayment + _paymentPerEmployee * _totalEmployees;
	}
	int GetTotal() { return _total; }
	string toString() {
		stringstream out;
		out << _type << ": " << endl;
		out << "- Name: " << _name << endl;
		out << "- FixedPayment: " << _fixedPayment << endl;
		out << "- TotalEmployees: " << _totalEmployees << endl;
		out << "- PaymentPerEmployee: " << _paymentPerEmployee << endl;
		out << "=> Final payment: " << _total << endl;
		return out.str();
	}
};

