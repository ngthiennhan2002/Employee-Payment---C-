#include "ConvertToEmployee.h"

EmployeeType ConvertToEmployee::checkType(string buffer) {
	stringstream split(buffer);
	string type, data;
	getline(split, type, ':');
	getline(split, data, ':');
	if (type.compare("DailyEmployee") == 0) {
		return VT_DailyEmployee;
	}
	else if (type.compare("HourlyEmployee") == 0) {
		return VT_HourlyEmployee;
	}
	else if (type.compare("ProductEmployee") == 0) {
		return VT_ProductEmployee;
	}
	else if (type.compare("Manager") == 0) {
		return VT_Manager;
	}
	return VT_NULL;
}

void ConvertToEmployee::convertToDailyEmployee(Employee*& temp, string buffer1, string buffer2) {
	stringstream splitName(buffer1);
	string tempStr, nameStr;
	getline(splitName, tempStr, ':');
	getline(splitName, nameStr, ':');
	nameStr.erase(0, 1);

	stringstream split(buffer2);
	string first, second;
	getline(split, first, ';');
	getline(split, second, ';');

	stringstream splitPayment(first);
	string dailyPaymentStr;
	getline(splitPayment, tempStr, '=');
	getline(splitPayment, dailyPaymentStr, '=');
	dailyPaymentStr.pop_back();

	stringstream splitTotalDays(second);
	string totalDaysStr;
	getline(splitTotalDays, tempStr, '=');
	getline(splitTotalDays, totalDaysStr, '=');
	
	int dailyPayment = stoi(dailyPaymentStr);
	int totalDays = stoi(totalDaysStr);

	temp->SetDataEmployee(nameStr, dailyPayment, totalDays);
	temp->CalculateTotal();
}

void ConvertToEmployee::convertToHourlyEmployee(Employee*& temp, string buffer1, string buffer2) {
	stringstream splitName(buffer1);
	string tempStr, nameStr;
	getline(splitName, tempStr, ':');
	getline(splitName, nameStr, ':');
	nameStr.erase(0, 1);

	stringstream split(buffer2);
	string first, second;
	getline(split, first, ';');
	getline(split, second, ';');

	stringstream splitPayment(first);
	string hourlyPaymentStr;
	getline(splitPayment, tempStr, '=');
	getline(splitPayment, hourlyPaymentStr, '=');
	hourlyPaymentStr.pop_back();

	stringstream splitTotalDays(second);
	string totalHoursStr;
	getline(splitTotalDays, tempStr, '=');
	getline(splitTotalDays, totalHoursStr, '=');

	int hourlyPayment = stoi(hourlyPaymentStr);
	int totalHours = stoi(totalHoursStr);

	temp->SetDataEmployee(nameStr, hourlyPayment, totalHours);
	temp->CalculateTotal();
}

void ConvertToEmployee::convertToProductEmployee(Employee*& temp, string buffer1, string buffer2) {
	stringstream splitName(buffer1);
	string tempStr, nameStr;
	getline(splitName, tempStr, ':');
	getline(splitName, nameStr, ':');
	nameStr.erase(0, 1);

	stringstream split(buffer2);
	string first, second;
	getline(split, first, ';');
	getline(split, second, ';');

	stringstream splitPayment(first);
	string paymentPerProductStr;
	getline(splitPayment, tempStr, '=');
	getline(splitPayment, paymentPerProductStr, '=');
	paymentPerProductStr.pop_back();

	stringstream splitTotalDays(second);
	string totalProductssStr;
	getline(splitTotalDays, tempStr, '=');
	getline(splitTotalDays, totalProductssStr, '=');

	int paymentPerProduct = stoi(paymentPerProductStr);
	int totalProducts = stoi(totalProductssStr);

	temp->SetDataEmployee(nameStr, paymentPerProduct, totalProducts);
	temp->CalculateTotal();
}

void ConvertToEmployee::convertToManager(Employee*& temp, string buffer1, string buffer2) {
	stringstream splitName(buffer1);
	string tempStr, nameStr;
	getline(splitName, tempStr, ':');
	getline(splitName, nameStr, ':');
	nameStr.erase(0, 1);

	stringstream split(buffer2);
	string first, second, third;
	getline(split, first, ';');
	getline(split, second, ';');
	getline(split, third, ';');

	stringstream splitFixedPayment(first);
	string fixedPaymentStr;
	getline(splitFixedPayment, tempStr, '=');
	getline(splitFixedPayment, fixedPaymentStr, '=');
	fixedPaymentStr.pop_back();

	stringstream splitTotalEmployees(second);
	string totalEmployeesStr;
	getline(splitTotalEmployees, tempStr, '=');
	getline(splitTotalEmployees, totalEmployeesStr, '=');

	stringstream splitPaymentPerEmployee(third);
	string paymentPerEmployeeStr;
	getline(splitPaymentPerEmployee, tempStr, '=');
	getline(splitPaymentPerEmployee, paymentPerEmployeeStr, '=');
	paymentPerEmployeeStr.pop_back();

	int fixedPayment = stoi(fixedPaymentStr);
	int totalEmployees = stoi(totalEmployeesStr);
	int paymentPerEmployee = stoi(paymentPerEmployeeStr);
	temp->SetDataManager(nameStr, fixedPayment, totalEmployees, paymentPerEmployee);
	temp->CalculateTotal();
}