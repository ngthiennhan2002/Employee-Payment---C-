#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>
#include <math.h>
#include <vector>
#include <memory>
#include "Employee.h"
#include "ReadFile.h"
#include "ConvertToEmployee.h"
#include "Factory.h"
using namespace std;

string filename = "November2021.txt";