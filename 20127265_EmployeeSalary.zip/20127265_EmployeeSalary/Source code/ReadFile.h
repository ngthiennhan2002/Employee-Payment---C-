#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>
#include <math.h>
#include <vector>
#include <memory>
using namespace std;

class ReadFile
{
private:
	string _filename;
public:
	ReadFile() {}
	ReadFile(string filename): _filename(filename){}
	vector<string> read();
};

