#pragma once
#include <iostream>
#include <regex>
#include <string>
#include <sstream>
#include <fstream>
#include <math.h>
#include <vector>
#include <memory>
#include "Employee.h"
using namespace std;

class ConvertToEmployee
{
public:
	static EmployeeType checkType(string);
	void convertToDailyEmployee(Employee*&, string, string);
	void convertToHourlyEmployee(Employee*&, string, string);
	void convertToProductEmployee(Employee*&, string, string);
	void convertToManager(Employee*&, string, string);
};

